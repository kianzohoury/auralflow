# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['auralflow',
 'auralflow.datasets',
 'auralflow.losses',
 'auralflow.models',
 'auralflow.trainer',
 'auralflow.utils',
 'auralflow.visualizer']

package_data = \
{'': ['*']}

install_requires = \
['asteroid>=0.5.2,<0.6.0',
 'librosa>=0.9.1,<0.10.0',
 'llvmlite>=0.38.1,<0.39.0',
 'matplotlib>=3.5.2,<4.0.0',
 'numpy>=1.22.4,<2.0.0',
 'protobuf==3.20.1',
 'tensorboard>=2.9.0,<3.0.0',
 'torch==1.10.0',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'auralflow',
    'version': '0.1.2',
    'description': 'A lightweight music source separation toolkit.',
    'long_description': None,
    'author': 'Kian Zohoury',
    'author_email': 'kzohoury@berkeley.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9.1,<3.11',
}


setup(**setup_kwargs)
