# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['auralflow',
 'auralflow.datasets',
 'auralflow.losses',
 'auralflow.models',
 'auralflow.trainer',
 'auralflow.utils',
 'auralflow.visualizer']

package_data = \
{'': ['*']}

install_requires = \
['asteroid>=0.5.2,<0.6.0',
 'librosa>=0.9.1,<0.10.0',
 'numpy==1.21.0',
 'protobuf==3.20.0',
 'tensorboard>=2.9.0,<3.0.0',
 'torch==1.10.0']

setup_kwargs = {
    'name': 'auralflow',
    'version': '0.1.2',
    'description': 'A lightweight music source separation toolkit.',
    'long_description': None,
    'author': 'Kian Zohoury',
    'author_email': 'kzohoury@berkeley.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.11,<3.11',
}


setup(**setup_kwargs)
